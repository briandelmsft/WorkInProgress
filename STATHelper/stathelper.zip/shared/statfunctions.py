import logging

def object_array_sort(req_body):
    logging.info('Loading sortObject Array')
    data = req_body.get('data')
    order = req_body.get('sortorder')
    sortkey = req_body.get('sortkey')

    if order == 'desc':
        reverseOrder = True
    else:
        reverseOrder = False

    try: 
        outData = sorted(data, key=lambda x: x[sortkey], reverse=reverseOrder)
    except:
        outData = {'Error': 'Unable to sort, check to confirm the sortkey is valid.'}
        outStatus=500
    else:
        outStatus = 200
    return {'outData': outData, 'outStatus': outStatus}


def object_array_sort_multi(req_body):
    logging.info('Loading sortObject Array')
    data = req_body.get('data')
    order = req_body.get('sortorder')
    sortkeys = req_body.get('sortkeys')

    if order == 'desc':
        reverseOrder = True
    else:
        reverseOrder = False

    try: 
        outData = sorted(data, key=lambda x: tuple(x[key] for key in sortkeys), reverse=reverseOrder)
    except:
        outData = {'Error': 'Unable to sort, check to confirm the sortkey is valid.'}
        outStatus=500
    else:
        outStatus = 200
    return {'outData': outData, 'outStatus': outStatus}
