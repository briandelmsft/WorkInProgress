import logging
import json

import azure.functions as func


def main(req: func.HttpRequest) -> func.HttpResponse:
    logging.info('Python HTTP trigger function processed a request.')

    try:
        req_body = req.get_json()
    except ValueError:
        pass
    else:
        action = req_body.get('action')
        data = req_body.get('data')

    if action == 'sortObjectArray':
        logging.info('Loading sortObject Array')
        order = req_body.get('sortorder')
        sortkey = req_body.get('sortkey')
        if order == 'desc':
            reverseOrder = True
        else:
            reverseOrder = False

        outData = sorted(data, key=lambda x: x[sortkey], reverse=reverseOrder)
        outStatus = 200

    else:
        logging.warn('Invalid Action')
        outData = {'Error': 'Invalid Action'}
        outStatus = 500

    return func.HttpResponse(json.dumps(outData), mimetype="application/json", status_code=outStatus)
